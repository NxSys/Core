<?php

/**
 * $BaseName$
 * $Id$
 *
 * DESCRIPTION
 *  Std mysqli_stmt wrapper support file
 *
 * @link http://nxsys.org/spaces/onx/wiki/Nexus_Common_Library
 * @link https://onx.zulipchat.com
 *
 * @package NxSys.Core\ESC
 * @license http://nxsys.org/spaces/onx/wiki/license
 * Please see the license.txt file or the url above for full copyright and license information.
 * @copyright Copyright 2018 Nexus Systems, inc.
 *
 * @author Chris R. Feamster <cfeamster@f2developments.com>
 * @author $LastChangedBy$
 *
 * @version $Revision$
 */

namespace NxSys\Core\ExtensibleSystemClasses\mysqli;

/**
 * Interface for mysqli_stmt
 *
 * This interface is an extraction of the prototype (contract) from the
 * respective class and exposes it as standard interface. It allows you to
 * 1) typehint on this interface and not miscellaneous concretions and
 * 2) augment and replace code with standard OOP hierarchies. Essentially we're
 * making these classes a little more SOLID.
 *
 * Note: Whith the presence of this interface (and related concretions) you can
 * now easily experiment with partial extensions of the decorated base class.
 * You are encouraged to do so, but do so with care as not all of the internal's
 * operation is well documented...
 *
 * @see \mysqli_stmt
 * @link http://php.net/manual/en/class.mysqli_stmt.php
 * @author Chris R. Feamster <cfeamster@f2developments.com>
 */
interface Imysqli_stmt
{
	public function __construct();


	public function attr_get($attribute);


	public function attr_set($attribute, $value);


	public function bind_param($types, &...$vars);


	public function bind_result(&...$vars);


	public function close();


	public function data_seek($offset);


	public function execute();


	public function fetch();


	public function get_warnings();


	public function result_metadata();


	public function more_results();


	public function next_result();


	public function num_rows();


	public function send_long_data($param_nr, $data);


	public function free_result();


	public function reset();


	public function prepare($query);


	public function store_result();


	public function get_result();
}
